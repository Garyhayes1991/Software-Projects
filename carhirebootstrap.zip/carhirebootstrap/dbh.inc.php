<?php

$dbservername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "mydb";

$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);

?>