<?php include('server.php')?>
<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>
	<link rel = "stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class = "header">
	   <h2>Login</h2>
	</div>
	
	<form method="post" action="login.php">
	    <?php include('errors.php');?>
	    <div class="input-group">
		    <label> Username</label>
			<input type="text" name="username">
		</div>
		<div class="input-group">
		    <label> Password</label>
			<input type="password" name="password">
		</div>
		<div class="input-group">
			<button type="submit" class="btn" name="login_user" class="btn">User Login</button>
			<button type="submit" class="btn" name="login_admin_user" class="btn">Admin Login</button>
		</div>	
		<p>
		    Not yet a Member? <a href="register.php">Sign Up</a>
		</p>
	</form>
</body>
</html>