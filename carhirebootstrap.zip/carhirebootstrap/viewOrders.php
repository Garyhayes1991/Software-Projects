<!DOCTYPE html>
<html lang="en">
<head>
  <title>Banger and Co!: Main Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
    
  .carousel-inner img {
      width: 100%; /* Set width to 100% */
      margin: auto;
      min-height:200px;
  }

  /* Hide the carousel text when the screen is less than 600 pixels wide */
  @media (max-width: 600px) {
    .carousel-caption {
      display: none; 
    }
  }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="MarketingIndex.php">Banger And Co!</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
		<li><a href="viewOrders.php">view Orders</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="loginAndRegister.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="container text-center">    
  <h3>View Orders</h3><br>
<div class="container">
	<div class="row">
		<div class="table-responsive">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>#</th>
            <th>Vehicle Type</th>
            <th>Full Name</th>
			<th>Age</th>
            <th>Email</th>
            <th>Date</th>
            <th>Price</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td><a href="#" target="_blank">Small Town Car - Hybrid</a></td>
            <td>Alex Bonafont</td>
			<td>23</td>
            <td>alex@gmail.com</td>
            <td>11/6/2014</td>
            <td>£100.00</td>
            <td><span class="label label-info">Processing</span></td>
          </tr>
          <tr>
            <td>2</td>
            <td><a href="#" target="_blank">Small Town Car - Petrol</a></td>
            <td>james thompson</td>
			<td>24</td>
            <td>james@gmail.com</td>
            <td>10/6/2014</td>
            <td>£125.00</td>
            <td><span class="label label-success">Shipped</span></td>
          </tr>
          <tr>
            <td>3</td>
            <td><a href="#" target="_blank">Large Family Car  - Saloon</a></td>
            <td>Ryan Vaughan</td>
			<td>24</td>
            <td>ryan@gmail.com</td>
            <td>11/9/2013</td>
            <td>£150.00</td>
            <td><span class="label label-info">Processing</span></td>
          </tr>
          <tr>
            <td>4</td>
            <td><a href="#" target="_blank">Large Family Car - Estate</a></td>
            <td>Sean Meyer</td>
			<td>23</td>
            <td>sean@gmail.com</td>
            <td>11/6/2014</td>
            <td>£75.00</td>
            <td><span class="label label-primary">Completed</span></td>
          </tr>
        </tbody>
      </table>
    </div>
	</div>
</div>
</div>

<footer class="container-fluid text-center">
  <p>Banger and Co! 2019</p>
</footer>

</body>
</html>