CREATE TABLE userprofile(
id int(11) AUTO_INCREMENT PRIMARY KEY not null,
firstname varchar(256) not null,
lastname varchar(256) not null,
phone int(11) not null,
email varchar(256) not null,
location varchar(256) not null,
password varchar(256) not null,
password2 varchar(256) not null,
accountnumber int(8) not null
);

INSERT INTO userprofile (firstname, lastname, phone, email, location, password, password2, accountnumber)
VALUES ('Gary', 'Hayes', 08123456543, 'gaz@gmail.com', 'stoke', 'password', 'password', 87654378);