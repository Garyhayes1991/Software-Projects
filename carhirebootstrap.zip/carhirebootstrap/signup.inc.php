<?php
include_once 'connectdatabase';

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$location = $_POST['location'];
$password = $_POST['password'];
$password2 = $_POST['password2'];
$accountnumber = $_POST['accountnumber'];

$sql = "INSERT INTO userprofile(firstname, lastname, phone, email, location, password, password2, accountnumber)
VALUES ('$firstname', '$lastname', '$phone', '$email', '$location', '$password', '$password2', '$accountnumber')";

mysqli_query($conn, $sql);

header("Location: pricing.php?submit=success");
