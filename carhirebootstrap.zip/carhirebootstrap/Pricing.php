<!DOCTYPE html>
<html lang="en">
<head>
  <title>Banger and Co!: Main Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
    
  .carousel-inner img {
      width: 100%; /* Set width to 100% */
      margin: auto;
      min-height:200px;
  }

  /* Hide the carousel text when the screen is less than 600 pixels wide */
  @media (max-width: 600px) {
    .carousel-caption {
      display: none; 
    }
  }
  * {
  box-sizing: border-box;
}

/* Create three columns of equal width */
.columns {
  float: left;
  width: 33.3%;
  padding: 6px;
}

/* Style the list */
.price {
  list-style-type: none;
  border: 1px solid #eee;
  margin: 0;
  padding: 0;
  -webkit-transition: 0.3s;
  transition: 0.3s;
}

/* Add shadows on hover */
.price:hover {
  box-shadow: 0 8px 10px 0 rgba(0,0,0,0.2)
}

/* Pricing header */
.price .header {
  background-color: #111;
  color: white;
  font-size: 10px;
}

/* List items */
.price li {
  border-bottom: 1px solid #eee;
  padding: 10px;
  text-align: center;
}

/* Grey list item */
.price .grey {
  background-color: #eee;
  font-size: 10px;
}

/* The "Sign Up" button */
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 10px 10px;
  text-align: center;
  text-decoration: none;
  font-size: 10px;
}

/* Change the width of the three columns to 100% 
(to stack horizontally on small screens) */
@media only screen and (max-width: 600px) {
  .columns {
    width: 100%;
  }
}
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="MarketingIndex.php">Banger And Co!</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="login.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container text-center">    
  <h3>View Prices</h3><br>
<div class="columns">
  <ul class="price">
    <li class="header">Small Town Car Hybrid</li>
    <li class="grey">£40.00</li>
    <li><input type="checkbox" name="check_list[]" value="satNav">SatNav</li>
	<li><input type="checkbox" name="check_list[]" value="babySeat">Baby Seat</li>
	<li><input type="checkbox" name="check_list[]" value="wineChiller">Wine Chiller</li>
	<li><input type="checkbox" name="check_list[]" value="rentfivehours">Rent for 5 Hours</li>
	<li><input type="checkbox" name="check_list[]" value="renttwoweeks">Rent for 2 weeks</li>
    <li class="grey"><a href="smalltowncarhybrid.php" class="button">Book Now</a></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">Small Town Car Petrol</li>
    <li class="grey">£40.00</li>
    <li><input type="checkbox" name="check_list[]" value="satNav">SatNav</li>
	<li><input type="checkbox" name="check_list[]" value="babySeat">Baby Seat</li>
	<li><input type="checkbox" name="check_list[]" value="wineChiller">Wine Chiller</li>
	<li><input type="checkbox" name="check_list[]" value="rentfivehours">Rent for 5 Hours</li>
	<li><input type="checkbox" name="check_list[]" value="renttwoweeks">Rent for 2 weeks</li>
    <li class="grey"><a href="smalltowncarpetrol.php" class="button">Book Now</a></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">Small Family Hatchback Petrol Manual</li>
    <li class="grey">£55.00</li>
    <li><input type="checkbox" name="check_list[]" value="satNav">SatNav</li>
	<li><input type="checkbox" name="check_list[]" value="babySeat">Baby Seat</li>
	<li><input type="checkbox" name="check_list[]" value="wineChiller">Wine Chiller</li>
	<li><input type="checkbox" name="check_list[]" value="rentfivehours">Rent for 5 Hours</li>
	<li><input type="checkbox" name="check_list[]" value="renttwoweeks">Rent for 2 weeks</li>
    <li class="grey"><a href="smallfamilyhtachpetrolman.php" class="button">Book Now</a></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">Small Family Hatchback Diesel Automatic</li>
    <li class="grey">£55.00</li>
    <li><input type="checkbox" name="check_list[]" value="satNav">SatNav</li>
	<li><input type="checkbox" name="check_list[]" value="babySeat">Baby Seat</li>
	<li><input type="checkbox" name="check_list[]" value="wineChiller">Wine Chiller</li>
	<li><input type="checkbox" name="check_list[]" value="rentfivehours">Rent for 5 Hours</li>
	<li><input type="checkbox" name="check_list[]" value="renttwoweeks">Rent for 2 weeks</li>
    <li class="grey"><a href="smallfamilyhatchdieselauto.php" class="button">Book Now</a></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">Large Family Saloon Diesel Automatic</li>
    <li class="grey">£60.00</li>
    <li><input type="checkbox" name="check_list[]" value="satNav">SatNav</li>
	<li><input type="checkbox" name="check_list[]" value="babySeat">Baby Seat</li>
	<li><input type="checkbox" name="check_list[]" value="wineChiller">Wine Chiller</li>
	<li><input type="checkbox" name="check_list[]" value="rentfivehours">Rent for 5 Hours</li>
	<li><input type="checkbox" name="check_list[]" value="renttwoweeks">Rent for 2 weeks</li>
    <li class="grey"><a href="largefamilysaloondieselauto.php" class="button">Book Now</a></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">Large Family Estate Petrol Manual</li>
    <li class="grey">£75.00</li>
    <li><input type="checkbox" name="check_list[]" value="satNav">SatNav</li>
	<li><input type="checkbox" name="check_list[]" value="babySeat">Baby Seat</li>
	<li><input type="checkbox" name="check_list[]" value="wineChiller">Wine Chiller</li>
	<li><input type="checkbox" name="check_list[]" value="rentfivehours">Rent for 5 Hours</li>
	<li><input type="checkbox" name="check_list[]" value="renttwoweeks">Rent for 2 weeks</li>
    <li class="grey"><a href="largefamilyestatepetrolman.php" class="button">Book Now</a></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">Medium Van</li>
    <li class="grey">£70.00</li>
    <li><input type="checkbox" name="check_list[]" value="satNav">SatNav</li>
	<li><input type="checkbox" name="check_list[]" value="babySeat">Baby Seat</li>
	<li><input type="checkbox" name="check_list[]" value="wineChiller">Wine Chiller</li>
	<li><input type="checkbox" name="check_list[]" value="rentfivehours">Rent for 5 Hours</li>
	<li><input type="checkbox" name="check_list[]" value="renttwoweeks">Rent for 2 weeks</li>
    <li class="grey"><a href="#" class="button">Book Now</a></li>
  </ul>
</div>
</div>

<footer class="container-fluid text-center">
  <p>Banger and Co! 2019</p>
  <li><a href="Contact.php">Contact Us</a></li>
</footer>

</body>
</html>